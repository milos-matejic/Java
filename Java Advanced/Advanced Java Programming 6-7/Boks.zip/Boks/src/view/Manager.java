package view;
import java.util.Scanner;
import model.Bokser;
public class Manager {
    
    public int menu(){
        System.out.println("*********************************************************************");
        System.out.println("1. Unesi, 2. Prikazi, 3. Edituj");
        System.out.println("*********************************************************************");
        Scanner s = new Scanner(System.in);
        return Integer.parseInt(s.nextLine());
    }
    
    public Bokser citaj(){
        Bokser res = new Bokser();
        Scanner s = new Scanner(System.in);
        System.out.println("Unesi ime: ");
        res.ime = s.nextLine();
        System.out.println("Unesi godine: ");
        res.godine = Integer.parseInt(s.nextLine());
        System.out.println("Unesi tezinu: ");
        res.tezina = Integer.parseInt(s.nextLine());
        return res;
    }
    
    public void izmeni(Bokser res){ 
        Scanner s = new Scanner(System.in);
        System.out.println("Unesi ime: ");
        String novoIme = s.nextLine();
        res.ime = novoIme.isEmpty() ? res.ime : novoIme;
        System.out.println("Unesi godine: ");
        String godine = s.nextLine();
        res.godine = godine.isEmpty() ? res.godine : Integer.parseInt(godine);
        System.out.println("Unesi tezinu: ");
        String tezina = s.nextLine();
        res.tezina = tezina.isEmpty() ? res.tezina : Integer.parseInt(tezina); 
    }
    
    public int getId(){
        System.out.println("Unesi id: ");
        Scanner s = new Scanner(System.in);
        return Integer.parseInt(s.nextLine());
    }
}

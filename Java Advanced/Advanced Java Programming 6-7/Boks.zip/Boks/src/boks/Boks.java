package boks; 
import controller.Controller;
import java.sql.SQLException;
import java.util.List;
import model.Bokser;
import model.Manager; 
public class Boks {
   public static void main(String[] args) throws SQLException {
        Controller c = new Controller();
        c.start();
   }
}

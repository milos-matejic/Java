package model;
public class Bokser {
    public int id;
    public String ime;
    public int tezina;
    public int godine;

    @Override
    public String toString() {
        return this.id + " " + this.ime + " " + this.tezina + " " + this.godine;
    }
}

package model; 
import java.sql.*; 
import java.util.ArrayList;
import java.util.List;
public class Manager {
    Connection connect() throws SQLException {
        return DriverManager.getConnection("jdbc:mysql://localhost/boks", "root", "");
    } 
    public void insert(Bokser bokser) throws SQLException{
        Connection conn = connect();
        PreparedStatement ps = conn.prepareStatement("insert into bokseri values (null,?,?,?)");
        ps.setString(1, bokser.ime);
        ps.setInt(2,bokser.tezina);
        ps.setInt(3, bokser.godine);
        ps.execute();
    }
    public void update(Bokser bokser) throws SQLException {
        Connection conn = connect();
        PreparedStatement ps = conn.prepareStatement("update bokseri set ime=?,tezina=?,godine=? where id = ?");
        ps.setString(1, bokser.ime);
        ps.setInt(2,bokser.tezina);
        ps.setInt(3, bokser.godine);
        ps.setInt(4, bokser.id);
        ps.execute();
    }
    
    public List citaj() throws SQLException{
        List res = new ArrayList();
        Connection conn = connect();
        PreparedStatement ps = conn.prepareStatement("select * from bokseri"); 
        ResultSet rs = ps.executeQuery();
        while(rs.next()){
            Bokser b = new Bokser();
            b.id = rs.getInt("id");
            b.ime = rs.getString("ime");
            b.godine = rs.getInt("godine");
            b.tezina = rs.getInt("tezina");
            res.add(b);
        }  
        return res;
    }
    
    public Bokser citaj(int id) throws SQLException{
        Bokser res = new Bokser();
        Connection conn = connect();
        PreparedStatement ps = conn.prepareStatement("select * from bokseri where id = ?");
        ps.setInt(1,id);
        ResultSet rs = ps.executeQuery();
        if(rs.next()){
            res.id = rs.getInt("id");
            res.ime = rs.getString("ime");
            res.godine = rs.getInt("godine");
            res.tezina = rs.getInt("tezina");
        } else {
            res = null;
        }
        return res;
    }
    
}

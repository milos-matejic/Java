package controller;
import java.sql.SQLException;
import java.util.List;
import model.Bokser;
import model.Manager; 
public class Controller {
    model.Manager dbManager;
    view.Manager viewManager; 
    public Controller(){
        dbManager = new Manager();
        viewManager = new view.Manager();
    }
    public void unesi() throws SQLException{
        Bokser b = viewManager.citaj();
        dbManager.insert(b);
    }
    public void prikazi()throws SQLException{
        List bokseri = dbManager.citaj();
        for(Object b : bokseri){
            System.out.println(b);
        }
    }
    public void edituj() throws SQLException {
        int id = viewManager.getId();
        Bokser b = dbManager.citaj(id);
        viewManager.izmeni(b);
        dbManager.update(b);
    }
    public void start() throws SQLException{
        while(true){
            int odabranaOpcija = viewManager.menu();
            switch(odabranaOpcija){
                case 1:
                    unesi();
                break;
                case 2:
                    prikazi();
                break;
                case 3:
                    edituj();
                break;
            }
        }
    }
}

package fitness;

import brain.Motor;
import java.sql.*;
import java.util.List;
import model.DbHelper;
import model.Rezultat;

public class Fitness {
    public static void main(String[] args) throws SQLException { 
            
            Motor.start();
    }
}

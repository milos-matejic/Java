package com.cars.model;
public class Car {
    public int id;
    public String model;
    public double price;
    public short year;
    public Car(int id, String model, double price, short year){
        this.id = id;
        this.model = model;
        this.price = price;
        this.year = year;
    }
    public Car(String model, double price, short year){ 
        this(-1,model,price,year); 
    }
    public Car(){}

    @Override
    public String toString() {
        return this.id + " " + this.model + " " + this.price + " " + this.year;
    } 
}

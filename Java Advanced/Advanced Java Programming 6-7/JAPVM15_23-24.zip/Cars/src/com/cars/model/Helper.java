package com.cars.model;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Helper {
    static String INSERT = "insert into cars values (null,?,?,?)";
    static String DELETE = "delete from cars where id = ?";
    static String UPDATE = "update cars set model=?,price=?,yop=? where id=?";
    static String GET = "select * from cars where id = ? limit 1";
    static String GET_ALL = "select * from cars";
    public Connection connect() throws SQLException{
        return DriverManager.getConnection("jdbc:mysql://localhost/cars", "root", "");
    }
    public List get() throws SQLException{
        List rezultat = new ArrayList();
        Connection conn = connect(); 
        PreparedStatement st = conn.prepareStatement(GET_ALL); 
        ResultSet res = st.executeQuery(); 
        while(res.next()){
            rezultat.add(new Car(res.getInt(1),res.getString(2),res.getDouble(3),res.getShort(4)));
        } 
        conn.close();
        return rezultat;
    }
    public Car get(int id) throws SQLException{
        Connection conn = connect();
        PreparedStatement st = conn.prepareStatement(GET);
        st.setInt(1,id);
        ResultSet res = st.executeQuery();
        Car result;
        if(res.next()){
            result = new Car(res.getInt(1),res.getString(2),res.getDouble(3),res.getShort(4));
        } else {
            result = null;
        }
        conn.close();
        return result;
    }
    public void update(Car car) throws SQLException {
        Connection conn = connect();
        PreparedStatement st = conn.prepareStatement(UPDATE);
        st.setString(1, car.model);
        st.setDouble(2, car.price);
        st.setShort(3, car.year);
        st.setInt(4, car.id);
        st.execute();
        conn.close();
    }
    public void add(Car car) throws SQLException {
        Connection conn = connect();
        PreparedStatement st = conn.prepareStatement(INSERT);
        st.setString(1, car.model);
        st.setDouble(2, car.price);
        st.setShort(3, car.year);
        st.execute();
        conn.close();
    }
    public void remove(int id) throws SQLException{
        Connection conn = connect();
        PreparedStatement st = conn.prepareStatement(DELETE);
        st.setInt(1, id);
        st.execute();
        conn.close();
    }
}

package com.cars.userinterface; 
import com.cars.model.Car;
import java.util.Scanner; 
public class UI {
    public Commands menu(){
        System.out.println("1. Add 2. Delete 3. Update 4. Show 5. Show all");
        Scanner s = new Scanner(System.in);
        int odabrano = Integer.parseInt(s.nextLine());
        return Commands.getById(odabrano);
    }
    public void change(Car c){
        Scanner s = new Scanner(System.in);
        System.out.println("Unesi model:");
        String model = s.nextLine();
        c.model = model.isEmpty() ? c.model : model;
        System.out.println("Unesi cenu:");
        String cena = s.nextLine();
        c.price = cena.isEmpty() ? c.price : Double.parseDouble(cena);
        System.out.println("Unesi godinu proizvodnje:");
        String yop = s.nextLine();
        c.year = yop.isEmpty() ? c.year : Short.parseShort(yop); 
    }
    
    public int getId(){
        Scanner s = new Scanner(System.in);
        System.out.println("Unesi id:");
        return Integer.parseInt(s.nextLine());
    }
    public Car get(){
        Scanner s = new Scanner(System.in);
        System.out.println("Unesi model:");
        String model = s.nextLine();
        System.out.println("Unesi cenu:");
        double cena = Double.parseDouble(s.nextLine());
        System.out.println("Unesi godinu proizvodnje:");
        short yop = Short.parseShort(s.nextLine());
        return new Car(model,cena,yop);
    }
}

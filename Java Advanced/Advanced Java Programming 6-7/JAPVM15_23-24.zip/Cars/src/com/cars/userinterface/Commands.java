package com.cars.userinterface;
public enum Commands {
    Add(1),Remove(2),Update(3),ShowAll(5),Show(4);
    public int cmdid;
    Commands(int cmdid){
        this.cmdid = cmdid;
    }
    public static Commands getById(int id){
        for(Commands c : Commands.values()){
            if(c.cmdid==id){
                return c;
            }
        }
        return null;
    }
}

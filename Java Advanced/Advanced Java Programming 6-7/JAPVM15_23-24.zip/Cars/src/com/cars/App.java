package com.cars;
import com.cars.model.*;
import com.cars.motor.Motor;
import java.sql.SQLException;
public class App {
    public static void main(String[] args) throws SQLException {
        Motor.start();
    }
}

package com.cars.motor;
import com.cars.model.*;
import com.cars.userinterface.*;
import java.sql.SQLException;
import java.util.List;
public class Motor { 
    Helper db;
    UI ui; 
    public Motor(){
        db = new Helper();
        ui = new UI();
    } 
    public void add() throws SQLException{
        Car zaUnos = ui.get();
        db.add(zaUnos);
    }
    public void remove() throws SQLException{
        int zaBrisanje = ui.getId();
        db.remove(zaBrisanje);
    }
    public void update() throws SQLException{
        int id = ui.getId();
        Car forChange = db.get(id);
        ui.change(forChange);
        db.update(forChange);
    }
    public void show() throws SQLException{
        int id = ui.getId();
        System.out.println(db.get(id));
    }
    public void showAll() throws SQLException{
        List all = db.get();
        for (Object all1 : all) {
            System.out.println(all1);
        }
    }
    public static void start() throws SQLException{
        Motor m = new Motor();
        while(true){
            Commands cmd = m.ui.menu();
            switch(cmd){
                case Add:
                    m.add();
                    break;
                case Remove:
                    m.remove();
                    break;
                case Update:
                    m.update();
                    break;
                case Show:
                    m.show();
                    break;
                case ShowAll:
                    m.showAll();
                    break;
            }
        }
    }
}
